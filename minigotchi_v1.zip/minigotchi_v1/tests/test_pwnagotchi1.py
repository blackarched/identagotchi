import threading
import pytest
from pwnagotchi1 import network_queue, shutdown_event

def test_queue_and_shutdown():
    # Ensure queue and event exist
    assert hasattr(network_queue, 'put')
    assert hasattr(shutdown_event, 'is_set')