import subprocess
import pytest
from password_brute import brute_force

def test_brute_force_writes_output(monkeypatch, tmp_path):
    output_dir = tmp_path / 'out'
    output_dir_str = str(output_dir)
    calls = []
    class DummyResult:
        stdout = 'password123'
    monkeypatch.setattr(subprocess, 'run', lambda cmd, capture_output, text: DummyResult())

    brute_force('dummy_target', 'dummy_wordlist', output_dir_str, logger=None)
    assert (output_dir / 'john_output.txt').exists()
    assert 'password123' in (output_dir / 'john_output.txt').read_text()