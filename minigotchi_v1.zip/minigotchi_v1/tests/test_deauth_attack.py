import subprocess
import pytest
from deauth_attack import deauth_attack

def test_deauth_attack_runs_without_error(monkeypatch, tmp_path):
    calls = []
    def dummy_run(cmd, check):
        calls.append(cmd)
    class DummyProc:
        pid = 1234
        def __init__(self, *args, **kwargs): pass
        def terminate(self): calls.append('terminate')
    monkeypatch.setattr(subprocess, 'run', dummy_run)
    monkeypatch.setattr(subprocess, 'Popen', lambda cmd, stdout, stderr: DummyProc())

    # Should not raise
    deauth_attack('wlan0', 'AA:BB:CC:DD:EE:FF', 6, 1, logger=None)
    assert any('terminate' == call for call in calls)