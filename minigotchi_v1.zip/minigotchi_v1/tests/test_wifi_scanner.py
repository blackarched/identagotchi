import os
import tempfile
import subprocess
import pytest
from wifi_scanner import scan_networks

def test_scan_networks_creates_file(monkeypatch, tmp_path):
    # Setup dummy subprocess result
    class DummyResult:
        stdout = 'Cell 01 - Address: AA:BB:CC:DD:EE:FF'
    def dummy_run(cmd, capture_output, check, text):
        return DummyResult()
    monkeypatch.setattr(subprocess, 'run', dummy_run)

    # Run scan_networks
    interface = 'wlan0'
    output_dir = str(tmp_path)
    logger = None  # scan_networks logs if logger provided
    scan_networks(interface, output_dir, logger)

    # Assert file created
    files = list(tmp_path.iterdir())
    assert len(files) == 1
    content = files[0].read_text()
    assert 'Address:' in content