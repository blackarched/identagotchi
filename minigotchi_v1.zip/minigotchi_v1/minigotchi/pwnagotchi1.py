from flask import Flask, render_template, request, redirect, url_for, flash
import os
from .config_loader import Config, ConfigError
from .wifi_scanner import WiFiScanner
from .deauth_attack import DeauthAttack
from .password_brute import PasswordBrute

app = Flask(__name__, static_folder='../static', template_folder='../templates')
app.secret_key = os.urandom(24)

# Load configuration
try:
    config = Config.load()
except ConfigError as e:
    raise SystemExit(f"Failed to load config: {e}")

# Ensure runtime dirs
for d in [config.log_dir, config.capture_dir, config.output_dir]:
    os.makedirs(d, exist_ok=True)

scanner = WiFiScanner(config)
deauth = DeauthAttack(config)
brute = PasswordBrute(config)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/scan')
def scan():
    try:
        results = scanner.scan()
        return render_template('view_scan.html', networks=results)
    except Exception as e:
        flash(str(e))
        return redirect(url_for('index'))

@app.route('/deauth', methods=['POST'])
def do_deauth():
    bssid = request.form['bssid']
    client = request.form.get('client') or None
    try:
        deauth.run(bssid, client)
        flash('Deauthentication attack successful')
    except Exception as e:
        flash(str(e))
    return redirect(url_for('index'))

@app.route('/brute', methods=['POST'])
def do_brute():
    cap = request.form['cap_file']
    try:
        success, output = brute.crack(cap)
        if success:
            flash('Password cracked successfully')
        else:
            flash('Password not found')
    except Exception as e:
        flash(str(e))
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)