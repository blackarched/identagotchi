import yaml
import os

class ConfigError(Exception):
    pass

class Config:
    def __init__(self, path=None):
        # Support both config.yaml and config.yml
        candidates = []
        if path:
            candidates.append(path)
        else:
            candidates.extend(["config.yaml", "config.yml"])
        found = None
        for p in candidates:
            if os.path.isfile(p):
                found = p
                break
        if not found:
            raise ConfigError(f"Configuration file not found (tried: {candidates})")
        try:
            with open(found, 'r') as f:
                data = yaml.safe_load(f)
        except yaml.YAMLError as e:
            raise ConfigError(f"Error parsing YAML in {found}: {e}")
        
        # Ensure required keys
        required = [
            "interface", "monitor_interface",
            "wordlist_small", "wordlist_big",
            "output_dir", "capture_dir", "log_dir"
        ]
        for key in required:
            if key not in data:
                raise ConfigError(f"Missing config parameter: {key}")
        
        # Load all config values into the instance
        for k, v in data.items():
            setattr(self, k, v)

    @classmethod
    def load(cls, path=None):
        return cls(path)