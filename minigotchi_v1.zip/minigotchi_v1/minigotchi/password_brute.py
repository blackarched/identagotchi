import subprocess
import os
import shlex
from .config_loader import Config

class PasswordBrute:
    def __init__(self, config: Config):
        self.wordlist_small = config.wordlist_small
        self.wordlist_big = config.wordlist_big
        self.output_dir = config.output_dir
        self.hashcat_threads = config.hashcat_threads
        self.use_gpu = config.use_gpu
        self.timeout = config.timeout_attack

    def crack(self, cap_file):
        # Validate cap exists
        if not os.path.isfile(cap_file):
            raise FileNotFoundError(f"Handshake file not found: {cap_file}")
        # Attempt with hashcat if available
        if self.use_gpu:
            cmd = [
                'hashcat', '-m', '2500', cap_file,
                self.wordlist_big,
                '--session', 'minigotchi',
                '-w', str(self.hashcat_threads)
            ]
        else:
            cmd = [
                'aircrack-ng', '-w', self.wordlist_small,
                '-l', os.path.join(self.output_dir, 'cracked.txt'),
                cap_file
            ]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            out, err = proc.communicate(timeout=self.timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            raise TimeoutError("Cracking process timed out")
        if proc.returncode != 0:
            raise RuntimeError(f"Cracking failed: {err.decode()}" )
        # Check success
        if b"KEY FOUND!" in out:
            return True, out.decode()
        return False, out.decode()