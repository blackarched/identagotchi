#!/usr/bin/env python3
import os
import sys
import json
from flask import (
    Flask, render_template, request, redirect,
    url_for, flash, jsonify
)

# Ensure the project root is in sys.path for absolute imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from minigotchi.config_loader import Config, ConfigError
from minigotchi.wifi_scanner import WiFiScanner
from minigotchi.deauth_attack import DeauthAttack
from minigotchi.password_brute import PasswordBrute

# Initialize Flask app with correct folders
app = Flask(
    __name__,
    static_folder=os.path.join(os.path.dirname(__file__), '..', 'static'),
    template_folder=os.path.join(os.path.dirname(__file__), '..', 'templates')
)
app.secret_key = os.urandom(24)

# Load configuration
try:
    config = Config.load()
except ConfigError as e:
    raise SystemExit(f"Failed to load config: {e}")

# Ensure runtime directories exist
for directory in [config.log_dir, config.capture_dir, config.output_dir]:
    os.makedirs(directory, exist_ok=True)

# Instantiate modules
scanner = WiFiScanner(config)
deauth = DeauthAttack(config)
brute = PasswordBrute(config)

# In-memory store for last scan
_last_scan = []

@app.route('/', methods=['GET'])
def index():
    return render_template('layout.html', networks=_last_scan)

@app.route('/scan', methods=['GET'])
def scan():
    global _last_scan
    try:
        _last_scan = scanner.scan()
        flash(f"Scan completed: found {len(_last_scan)} networks")
    except Exception as e:
        flash(f"Scan error: {e}")
    return redirect(url_for('index'))

@app.route('/deauth', methods=['POST'])
def do_deauth():
    bssid = request.form.get('bssid')
    client = request.form.get('client') or None
    if not bssid:
        flash("BSSID is required for deauth")
        return redirect(url_for('index'))

    try:
        deauth.run(bssid, client)
        flash("Deauthentication attack sent")
    except Exception as e:
        flash(f"Deauth error: {e}")
    return redirect(url_for('index'))

@app.route('/brute', methods=['POST'])
def do_brute():
    cap_file = request.form.get('cap_file')
    if not cap_file:
        flash("Capture file path is required")
        return redirect(url_for('index'))

    cap_path = (cap_file if os.path.isabs(cap_file)
                else os.path.join(config.capture_dir, cap_file))
    try:
        success, output = brute.crack(cap_path)
        if success:
            flash("Password cracked successfully")
        else:
            flash("Password not found")
    except Exception as e:
        flash(f"Brute error: {e}")
    return redirect(url_for('index'))

@app.route('/api/stats', methods=['GET'])
def api_stats():
    stats = {
        'scan_count': len(_last_scan),
        'last_scan': _last_scan,
    }
    return jsonify(stats)

@app.errorhandler(404)
def not_found(e):
    flash("Page not found")
    return redirect(url_for('index'))

@app.errorhandler(500)
def server_error(e):
    flash("Internal server error")
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=False)