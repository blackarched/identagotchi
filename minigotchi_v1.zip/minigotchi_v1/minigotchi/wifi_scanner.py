import subprocess
import os
import time
from .config_loader import Config

class WiFiScanner:
    def __init__(self, config: Config):
        self.iface = config.interface
        self.mon_iface = config.monitor_interface
        self.capture_dir = config.capture_dir
        self.timeout_scan = getattr(config, 'timeout_scan', 30)

    def start_monitor(self):
        subprocess.run(['sudo', 'airmon-ng', 'check', 'kill'], check=False)
        subprocess.run(['sudo', 'airmon-ng', 'start', self.iface], check=True)

    def stop_monitor(self):
        subprocess.run(['sudo', 'airmon-ng', 'stop', self.mon_iface], check=False)

    def scan(self):
        self.start_monitor()
        timestamp = int(time.time())
        base = os.path.join(self.capture_dir, f"scan_{timestamp}")
        csv_file = f"{base}.csv"

        cmd = [
            'sudo', 'airodump-ng', '--output-format', 'csv',
            '-w', base, self.mon_iface
        ]
        proc = subprocess.Popen(cmd, cwd=self.capture_dir)
        start_time = time.time()

        # Wait for CSV file
        while not os.path.exists(csv_file):
            if time.time() - start_time > self.timeout_scan:
                proc.kill()
                raise TimeoutError("Scan CSV file not generated within timeout")
            time.sleep(1)

        proc.terminate()
        return self._parse_csv(csv_file)

    def _parse_csv(self, filepath):
        results = []
        with open(filepath, 'r') as f:
            for line in f:
                if line.startswith('#') or not line.strip():
                    continue
                parts = [p.strip() for p in line.split(',')]
                if len(parts) < 14:
                    continue
                bssid = parts[0]
                channel = parts[3]
                ssid = parts[13]
                results.append({
                    'bssid': bssid,
                    'channel': channel,
                    'ssid': ssid
                })
        return results