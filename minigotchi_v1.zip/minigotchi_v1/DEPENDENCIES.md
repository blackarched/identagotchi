# External Dependencies for Minigotchi

This document lists all system-level tools and libraries required for Minigotchi to function correctly.

## 1. Aircrack-ng Suite
- **Packages:** `aircrack-ng` (includes `aireplay-ng`, `airodump-ng`, `aircrack-ng`)
- **Installation:**
  ```bash
  sudo apt-get update
  sudo apt-get install aircrack-ng