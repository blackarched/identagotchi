#!/usr/bin/env bash
# Example cron job script for periodic scans
cd $(dirname "$0")
python3 -m minigotchi.pwnagotchi1 scan >> logs/cron_scan.log 2>&1